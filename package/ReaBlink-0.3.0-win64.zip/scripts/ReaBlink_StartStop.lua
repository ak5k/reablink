if reaper.Blink_GetEnabled() and reaper.Blink_GetPuppet() then
  reaper.Blink_StartStop()
end
